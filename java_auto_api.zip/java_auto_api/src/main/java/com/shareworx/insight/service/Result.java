package com.shareworx.insight.service;

import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

public interface Result {
    Map<String,Object> result(Map<String,Object> actual);
    void setFileList(List<MultipartFile> files);
    List<MultipartFile> getFileList();

    long getCount();
}
