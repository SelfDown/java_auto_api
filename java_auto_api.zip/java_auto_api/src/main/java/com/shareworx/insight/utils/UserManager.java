package com.shareworx.insight.utils;

import com.shareworx.auth.shiro.model.PlatformUserModel;
import com.shareworx.insight.service.Result;
import com.shareworx.insight.service_platform_query.ServicePlatformQuery;
import com.shareworx.platform.util.SpringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UserManager {
    public static String getCurrentPkUser(){
        PlatformUserModel currentUser1 = com.shareworx.auth.shiro.util.UserManager.getCurrentUser();
        PlatformUserModel currentUser = com.shareworx.auth.shiro.util.UserManager.getCurrentUser();
        if(currentUser == null){
            return null;
        }
        return currentUser.getPk_user();
    }


    public static Map<String,Object> getUserInfo(){
        Result result_service = SpringUtils.getBean(ServicePlatformQuery.ID);
        Map<String,Object> user_info_query = new HashMap<>();
        user_info_query.put("service","user_info_query");
        Map<String,Object> search_fields = new HashMap<>();
        search_fields.put("pk_user",getCurrentPkUser());
        user_info_query.put("search_fields",search_fields);
        try{
            Map<String, Object> result = result_service.result(user_info_query);
            List<Map<String, Object>> data = ( List<Map<String, Object>>) result.get("data");
            if(data.size()>0){
                return data.get(0);
            }else{
                return null;
            }

        }catch(Exception ex){
            return null;
        }


    }
}
