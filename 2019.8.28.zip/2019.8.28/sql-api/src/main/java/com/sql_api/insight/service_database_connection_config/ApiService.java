package com.sql_api.insight.service_database_connection_config;

public interface ApiService {
}
