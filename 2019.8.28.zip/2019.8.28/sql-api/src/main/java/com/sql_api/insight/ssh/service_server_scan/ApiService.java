package com.sql_api.insight.ssh.service_server_scan;

import com.alibaba.fastjson.JSONObject;

import java.util.Map;

public interface ApiService {
    Map<String,Object> connect(String ip,int port,int timeout);
}
