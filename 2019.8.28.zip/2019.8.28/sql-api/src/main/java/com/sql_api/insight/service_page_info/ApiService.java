package com.sql_api.insight.service_page_info;

public interface ApiService {
}
