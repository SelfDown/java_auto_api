package com.sql_api.insight.service_database_table;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sql_api.insight.model.ApiModel;
import com.sql_api.insight.service.ResultBaseService;
import com.sql_api.insight.data_source.DatabaseConnections;
import com.sql_api.insight.utils.EnvUtils;

import com.sql_api.insight.utils.ServicePlatformCreateUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


@Service(ServiceDatabaseTable.ID)
public class ServiceDatabaseTable extends ResultBaseService implements ApiService {
    public static final String ID = "service_database_table";
    @Override
    public Map<String, Object> result(Map<String, Object> actual) {
        String service = (String) actual.get("service");
        ApiModel apiModel = getApiModel(service);
        String template_final = apiModel.getTemplate();
        JSONObject final_template = JSON.parseObject(template_final);

        boolean hasTable = checkTableExists(final_template);
        if(!hasTable){
            Map<String, Object> createTableSQL = getCreateTableSQL(final_template);
            if(!(boolean)createTableSQL.get("success")){
                return createTableSQL;
            }
            JdbcTemplate writeTemplate = DatabaseConnections.getWriteTemplate();
            String sql = (String) createTableSQL.get("sql");


            writeTemplate.execute(sql);
            //创建数据
            String init_data_service = final_template.getString("init_data_service");
            if(!StringUtils.isEmpty(init_data_service)){
                ServicePlatformCreateUtils.result(init_data_service,new HashMap<>());
            }
            return getResult(true,"创建表成功");
        }else{
           getFieldsDescFromDataBase(final_template);
           getDifferentField(final_template);
           getDifferentEngine(final_template);
           List<String> alterTableSQL = getAlterTableSQL(final_template);

           if(alterTableSQL.size()>0){
               JdbcTemplate writeTemplate = DatabaseConnections.getWriteTemplate();
               writeTemplate.batchUpdate( alterTableSQL.toArray(new String[0]));
               return getResult(true,"更新表成功");
           }else{
               return getResult(true,"已经是最新的");
           }
        }

    }

    private void getDifferentEngine(JSONObject final_template){
        JdbcTemplate readTemplate = DatabaseConnections.getReadTemplate();
        String sql = "show table status where name = '" + final_template.getString("table_name") + "';  ";
        List<Map<String,Object>> list = readTemplate.queryForList(sql);
        Map<String, Object> map = list.get(0);
        String engine = (String) map.get("Engine");
        engine = engine.toLowerCase();
        String final_templateString = final_template.getString("engine");
        if(!StringUtils.isEmpty(final_templateString) && !engine.equals(final_templateString)){
            String engine_sql = "alter table operation_log ENGINE = '"+final_templateString+"';";
            final_template.put("engine_sql",engine_sql);

        }


    }

    private List<String> getAlterTableSQL(JSONObject final_template){
        List<String> list = new ArrayList<>();
        JSONArray newFields = final_template.getJSONArray("newFields");
        String table_name = final_template.getString("table_name");
        for(int i=0;i<newFields.size();i++){
            JSONObject field = newFields.getJSONObject(i);
            StringBuilder sb = new StringBuilder();
            sb.append("alter table "+table_name+" add  ");
            String field_1 = field.getString("field_1");
            sb.append(field_1);
            String[] field_type = field.getString("field_3").split(",");
            if(field_type.length>1){
                sb.append(" "+field_type[0]+"("+field_type[1]+")");
            }else{
                sb.append(" "+field_type[0]+" ");
            }
            sb.append(";");
            list.add(sb.toString());
        }
        JSONArray updateFields = final_template.getJSONArray("updateFields");
        for(int i=0;i<updateFields.size();i++){
            JSONObject field = updateFields.getJSONObject(i);
            StringBuilder sb = new StringBuilder();
            sb.append("alter table "+table_name+" modify ");
            String field_1 = field.getString("field_1");
            sb.append(field_1);
            String[] field_type = field.getString("field_3").split(",");
            if(field_type.length>1){
                sb.append(" "+field_type[0]+"("+field_type[1]+")");
            }else{
                sb.append(" "+field_type[0]+" ");
            }

            sb.append(";");
            list.add(sb.toString());
        }


        //修改引擎
        if(final_template.containsKey("engine_sql")){
            list.add(final_template.getString("engine_sql"));
        }

        if(EnvUtils.isDebugger()){
            System.out.println(list);
        }
       return list;

    }
    private void getFieldsDescFromDataBase(JSONObject final_template){
        JdbcTemplate readTemplate = DatabaseConnections.getReadTemplate();
        List<Map<String, Object>> fields = readTemplate.queryForList("desc " + final_template.getString("table_name"));
        Map<String,Object> data = new HashMap<>();
        for(int i= 0;i<fields.size();i++){
            Map<String, Object> field = fields.get(i);
            data.put(field.get("Field")+"",field);
        }
        final_template.put("fields_from_database",data);
    }

    private void getDifferentField(JSONObject final_template){
        JSONArray fields = final_template.getJSONArray("fields");
        Map<String,Object> fields_from_database = (Map<String, Object>) final_template.get("fields_from_database");
        List<JSONObject> newFields = new ArrayList<>();
        List<JSONObject> updateFields = new ArrayList<>();
        for(int i=0;i<fields.size();i++){
            JSONObject field = fields.getJSONObject(i);
            String field_name = field.getString("field_1");
            if(fields_from_database.containsKey(field_name)){//如果存在，检查是否有更新
                Map<String,Object> field_from_database = (Map<String, Object>) fields_from_database.get(field_name);
                String type = (String) field_from_database.get("Type");
                String[] data_type = type.split("\\(");
                String field_3 = field.getString("field_3");
                String[] field_3_type = field_3.split(",");
                //如果字段名称不同
                if(!data_type[0].equals(field_3_type[0])){
                    updateFields.add(field);
                    continue;
                }
                //长度不同
                if(field_3_type.length>1){
                    //数据库存在长度
                    if(data_type.length>1){//比较长度
                        String data_type_length = data_type[1].split("\\)")[0];
                        if(!data_type_length.equals(field_3_type[1])){//长度不同则修改
                          updateFields.add(field);
                        }
                    }else{//todo 数据库里没有长度， 是否需要修改？
                        //updateFields.add(field);
                    }
                }
            }else{//不存在，就添加
                newFields.add(field);
            }
        }

        final_template.put("newFields",newFields);
        final_template.put("updateFields",updateFields);

    }

    private Map<String,Object> getCreateTableSQL(JSONObject final_template ){
        StringBuilder sb = new StringBuilder();
        sb.append("create table ");
        sb.append(" "+final_template.getString("table_name")+" ( ");
        JSONArray fields = final_template.getJSONArray("fields");

        for(int i=0;i<fields.size();i++){

            JSONObject object = fields.getJSONObject(i);
            String field_1 = object.getString("field_1");
            sb.append(" "+field_1+" ");


            String field_3 = object.getString("field_3");
            String[] fields_arr = field_3.split(",");
            if(fields_arr.length<=0){
                return getResult(false,field_1+" 类型字段不能为空");
            }
            if(fields_arr.length==1){
                sb.append(fields_arr[0] );
            }else{
                sb.append(" "+fields_arr[0]+" " +"("+fields_arr[1]+") ");
            }

            if("primary_key".equals(object.getString("field_4"))){
                sb.append(" primary key ");
            }

            if(i!=(fields.size()-1)){
                sb.append(" , ");
            }
        }
        sb.append(" ) ");

        if(final_template.containsKey("engine")){
            String engine = final_template.getString("engine");
            sb.append(" engine="+engine);
        }
        Map<String,Object> data = new HashMap<>();
        data.put("sql",sb.toString());
        data.put("success",true);
        return data;
    }
    @Override
    public boolean checkTableExists(JSONObject final_template) {
        JdbcTemplate readTemplate = DatabaseConnections.getReadTemplate();
        List<String> table_name = readTemplate.queryForList("show tables like '" + final_template.getString("table_name") + "'; ", String.class);
        if(table_name.size()<=0){
            return false;
        }else {
            return true;
        }

    }
}
