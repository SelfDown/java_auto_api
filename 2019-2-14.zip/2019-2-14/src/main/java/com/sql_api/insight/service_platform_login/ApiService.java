package com.sql_api.insight.service_platform_login;

import com.alibaba.fastjson.JSONObject;

import java.util.Map;

public interface ApiService {

}
