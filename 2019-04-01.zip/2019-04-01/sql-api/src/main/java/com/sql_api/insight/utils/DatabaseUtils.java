package com.sql_api.insight.utils;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sql_api.insight.model.ApiModel;
import com.sql_api.insight.service.ApiService;
import org.springframework.util.StringUtils;

public class DatabaseUtils {
    static String database_type = null;
    public static boolean isMySQL(){
       return getDatabaseType().equals("mysql");
//        return  true;
    }
    public static String getDatabaseType(){
       if(!StringUtils.isEmpty(database_type)){
           return database_type;
       }
        ApiService bean = SpringUtils.getBean(ApiService.ID);
        ApiModel service_read_source = bean.queryByService("service_read_source");
        JSONObject object = JSON.parseObject(service_read_source.getTemplate());
        database_type = object.getString("database_type").toLowerCase();
        return database_type;
    }
    public static boolean isOracle(){
        return getDatabaseType().equals("oracle");
//        return false;
    }
}
