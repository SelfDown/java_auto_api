package com.sql_api.insight.utils;

public interface IEncryptStrategy {
    byte[] execute();
}