package com.sql_api.insight.utils;


import org.apache.log4j.Logger;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

public class ShaEncryptStrategy implements IEncryptStrategy {
    private Logger log = Logger.getLogger(ShaEncryptStrategy.class);
    private IEncryptStrategy instance;

    public ShaEncryptStrategy(IEncryptStrategy instance) {
        this.instance = instance;
    }

    public byte[] execute() {
        byte[] bytes = this.instance.execute();
        this.log.debug("SHA加密");
        this.log.debug(Arrays.toString(bytes));

        try {
            MessageDigest md = MessageDigest.getInstance("SHA1");
            return md.digest(bytes);
        } catch (NoSuchAlgorithmException var3) {
            this.log.error(var3.getMessage(), var3);
            return bytes;
        }
    }
}
