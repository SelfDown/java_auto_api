var config = {
	data:{
		message:"自动功能页面测试",
		show:{
				username:"admin",
				password:"e10adc3949ba59abbe56e057f20f883e",
				json_data:"{}",
	  			module:"database_connection_config",
	  			dataList: [],
	  			fields:[

	  			
	  			],
	  			operation:"",
	  			form_data:{

	  			}
	  	},

	  	loginURL:"/auth/login.do",
	  	//loginURL:"/dict/query",
	  	
	  	getDataURL:"/insight/tools/query",
	  	saveDataURL:"/insight/tools/save",
	  	updateDataURL:"/insight/tools/update",
	  	deleteDataURL:"/insight/tools/delete",
	  	serviceResultURL:"insight/service/result",
		functions:[

			{
	  			name:"platform_query",
	  			fields:[
	  					{
	  					showName:"",
	  					name:"service_type",
	  					must_send:false,
	  					must_save:true,
	  					type:"hidden",
	  					placeholder:"",
	  					value:"service_platform_query"
	  					},
		  				{
		  					showName:"",
		  					name:"type",
		  					must_send:false,
		  					must_save:true,
		  					type:"hidden",
		  					placeholder:"",
		  					value:"platform_query"
		  				},
		  				{
		  					showName:"service",
		  					name:"service",
		  					must_send:true,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"服务访问名称",
		  				},
		  				{
		  					showName:"备注",
		  					name:"backup",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"",
		  				},
		  				{
		  					showName:"SQL",
		  					name:"sql",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"查询sql语句",
		  				},

		  				{
		  					showName:"login_require,是否需要登陆",
		  					name:"login_require",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"是否需要登陆",
		  					value:"true"
		  				},
		  				{
		  					showName:"toTree,是否转成树形结构，以逗号隔开，如'id,parent_id,childrens'字段，空就是列表,虚拟节点delete_flag=0,id=0 ",
		  					name:"toTree",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"是否转成树形结构，空就是列表",
		  					value:""
		  				},

		  				{
		  					showName:"搜索字段，between_and为字符串",
		  					name:"search_fields",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"搜索字段",
		  					value:[

		  							{
		  								"field_1":"page",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"页数",
			  							"field_2_placeholder":"描述",
			  							"field_3":"I",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列校验规则。如S，must。表示类型为字符串。必须传",
			  							"field_4":"=",
			  							"field_4_placeholder":"操作 in、=、like、between_and、date_between_and",
			  							"field_5":"1",
			  							"field_5_placeholder":"默认值"
		  							},

		  							{
		  								"field_1":"size",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"数量",
			  							"field_2_placeholder":"描述",
			  							"field_3":"I",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列校验规则。如S，must。表示类型为字符串。必须传",
			  							"field_4":"=",
			  							"field_4_placeholder":"操作:in、=、like、between_and、date_between_and",
			  							"field_5":"10",
			  							"field_5_placeholder":"默认值"
		  							},

		  							{"field_1":"",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"",
			  							"field_2_placeholder":"描述",
			  							"field_3":"",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列校验规则。如S，must。表示类型为字符串。必须传",
			  							"field_4":"",
			  							"field_4_placeholder":"操作:in、=、like、between_and、date_between_and",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
			  						}
		  							]
		  				},

		  				{
		  					showName:"默认搜索字段，between_and为字符串",
		  					name:"default_search_fields",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"搜索字段",
		  					value:[

		  							{
		  								"field_1":"delete_flag",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"是否删除",
			  							"field_2_placeholder":"描述",
			  							"field_3":"S",
			  							"field_3_placeholder":"类型 S、I",
			  							"field_4":"=",
			  							"field_4_placeholder":"操作 in、=、like、between_and、date_between_and",
			  							"field_5":"0",
			  							"field_5_placeholder":"默认值"
		  							},

		  							
		  							]
		  				},

		  				{
		  					showName:"显示字段",
		  					name:"show_fields",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"显示字段",
		  					value:[{"field_1":"",
		  							"field_1_placeholder":"字段",
		  							"field_2":"",
		  							"field_2_placeholder":"描述",
		  							"field_3":"",
		  							"field_3_placeholder":"显示:true/false",
		  							"field_4":"",
		  							"field_4_placeholder":"更新:true/false",
		  							"field_5":"",
		  							"field_5_placeholder":"备用",
		  							}
		  							]
		  				},


		  				{
		  					showName:"排序字段",
		  					name:"order_fields",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"显示字段",
		  					value:[{"field_1":"",
		  							"field_1_placeholder":"字段",
		  							"field_2":"",
		  							"field_2_placeholder":"描述",
		  							"field_3":"",
		  							"field_3_placeholder":"",
		  							"field_4":"",
		  							"field_4_placeholder":"",
		  							"field_5":"",
		  							"field_5_placeholder":"desc|asc",
		  							}
		  							]
		  				}


		  				
		  				]

	  			},
	  		
	  	
	  		{
	  			name:"platform_create",
	  			fields:[
	  					{
	  					showName:"",
	  					name:"service_type",
	  					must_send:false,
	  					must_save:true,
	  					type:"hidden",
	  					placeholder:"",
	  					value:"service_platform_create"
	  					},
		  				{
		  					showName:"",
		  					name:"type",
		  					must_send:false,
		  					must_save:true,
		  					type:"hidden",
		  					placeholder:"",
		  					value:"platform_create"
		  				},
		  				{
		  					showName:"service",
		  					name:"service",
		  					must_send:true,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"服务访问名称",
		  				},
		  				{
		  					showName:"备注",
		  					name:"backup",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"",
		  				},
		  				{
		  					showName:"数据库表",
		  					name:"table_name",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"数据库表",
		  				},
		  				{
		  					showName:'新增数据字段,使用\"，默认字段同时存在，优先数据字段。第五列规则 {"delete_field_mode":{"username":"$now$","deleteflag":0},"delete_service_mode":{"service":"user_exitst","search_fields":{"username":"$now$"}}}',
		  					name:"fields",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"新增数据字段",
		  					value:[

		  							{
		  								"field_1":"nickname",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"名称",
			  							"field_2_placeholder":"描述",
			  							"field_3":"S",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列校验规则。如S，must。表示类型为字符串。必须传[S、I],[must、unique、update_unique]",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"",
			  							"field_5_placeholder":"是否伪删除,必须为JSON"
		  							},
		  							{
		  								"field_1":"username",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"用户名",
			  							"field_2_placeholder":"描述",
			  							"field_3":"S,must",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列校验规则。如S，must。表示类型为字符串。必须传[S、I],[must、unique、update_unique]",
			  							"field_4":'{"delete_field_mode":{"username":"$now$","deleteflag":0}}',
			  							"field_4_placeholder":"是否伪删除,必须为JSON",
			  							'field_5':'',
			  							"field_5_placeholder":"默认值"
		  							},

		  							
		  							]
		  				},

		  				{
		  					showName:"默认字段",
		  					name:"default_fields",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"默认字段",
		  					value:[
		  							{"field_1":"pk_user",
		  							"field_1_placeholder":"字段",
		  							"field_2":"是否删除",
		  							"field_2_placeholder":"描述",
		  							"field_3":"UUID",
		  							"field_3_placeholder":"类型 S、I、D、USER_ID,DATETIME,UUID",
		  							"field_4":"",
		  							"field_4_placeholder":"",
		  							"field_5":"",
		  							"field_5_placeholder":"默认值",
		  							},
		  							{"field_1":"deleteflag",
		  							"field_1_placeholder":"字段",
		  							"field_2":"是否删除",
		  							"field_2_placeholder":"描述",
		  							"field_3":"I",
		  							"field_3_placeholder":"类型 S、I、D、USER_ID,DATETIME,UUID",
		  							"field_4":"",
		  							"field_4_placeholder":"",
		  							"field_5":"0",
		  							"field_5_placeholder":"默认值",
		  							},
		  							{"field_1":"updateby",
		  							"field_1_placeholder":"字段",
		  							"field_2":"是否删除",
		  							"field_2_placeholder":"描述",
		  							"field_3":"USER_ID",
		  							"field_3_placeholder":"类型 S、I、D、USER_ID,DATETIME,UUID",
		  							"field_4":"",
		  							"field_4_placeholder":"",
		  							"field_5":"",
		  							"field_5_placeholder":"默认值",
		  							},
		  							{"field_1":"updatetime",
		  							"field_1_placeholder":"字段",
		  							"field_2":"是否删除",
		  							"field_2_placeholder":"描述",
		  							"field_3":"DATETIME",
		  							"field_3_placeholder":"类型 S、I、D、USER_ID、DATETIME,UUID",
		  							"field_4":"",
		  							"field_4_placeholder":"",
		  							"field_5":"",
		  							"field_5_placeholder":"默认值",
		  							}
		  						]
		  				}


		  				
		  				]
	  		},
	  		
	  			{
	  			name:"platform_update",
	  			fields:[
	  					{
	  					showName:"",
	  					name:"service_type",
	  					must_send:false,
	  					must_save:true,
	  					type:"hidden",
	  					placeholder:"",
	  					value:"service_platform_update"
	  					},
		  				{
		  					showName:"",
		  					name:"type",
		  					must_send:false,
		  					must_save:true,
		  					type:"hidden",
		  					placeholder:"",
		  					value:"platform_update"
		  				},
		  				{
		  					showName:"service",
		  					name:"service",
		  					must_send:true,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"服务访问名称",
		  				},
		  				{
		  					showName:"备注",
		  					name:"backup",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"",
		  				},
		  				{
		  					showName:"数据库表",
		  					name:"table_name",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"数据库表",
		  				},
		  				{
		  					showName:'修改数据字段,使用\"，默认字段同时存在，优先数据字段,{"delete_field_mode":{"username":"$now$","deleteflag":0},"delete_service_mode":{"service":"user_exitst","search_fields":{"username":"$now$"}}}',
		  					name:"fields",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"修改数据字段",
		  					value:[

		  							{
		  								"field_1":"nickname",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"名称",
			  							"field_2_placeholder":"描述",
			  							"field_3":"S",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列校验规则。如S，must。表示类型为字符串。必须传",
			  							"field_4":"",
			  							"field_4_placeholder":"是否伪删除,必须为JSON",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							},
		  							{
		  								"field_1":"username",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"用户名",
			  							"field_2_placeholder":"描述",
			  							"field_3":"S,must",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列校验规则。如S，must。表示类型为字符串。必须传",
			  							"field_4":'{"delete_field_mode":{"username":"$now$","deleteflag":0}}',
			  							"field_4_placeholder":"是否伪删除,必须为JSON",
			  							'field_5':'',
			  							"field_5_placeholder":"默认值"
		  							},

		  							
		  							]
		  				},

		  				

		  				{
		  					showName:"条件筛选字段",
		  					name:"filters",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"条件筛选字段",
		  					value:[
		  							
		  							{"field_1":"pk_user",
		  							"field_1_placeholder":"字段",
		  							"field_2":"是否删除",
		  							"field_2_placeholder":"描述",
		  							"field_3":"S",
		  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列校验规则。如S，must。表示类型为字符串。必须传",
		  							"field_4":"",
		  							"field_4_placeholder":"",
		  							"field_5":'',
		  							"field_5_placeholder":"默认值",
		  							}
		  						]
		  				},
		  				{
		  					showName:"默认条件字段",
		  					name:"default_filters",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"默认条件字段",
		  					value:[
		  							
		  							
		  							{"field_1":"deleteflag",
		  							"field_1_placeholder":"字段",
		  							"field_2":"是否删除",
		  							"field_2_placeholder":"描述",
		  							"field_3":"I",
		  							"field_3_placeholder":"类型 S、I、D、USER_ID、DATETIME,UUID",
		  							"field_4":"",
		  							"field_4_placeholder":"",
		  							"field_5":"0",
		  							"field_5_placeholder":"默认值",
		  							}
		  						]
		  				},
		  				{
		  					showName:"默认字段",
		  					name:"default_fields",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"默认字段",
		  					value:[
		  							
		  							{"field_1":"updateby",
		  							"field_1_placeholder":"字段",
		  							"field_2":"是否删除",
		  							"field_2_placeholder":"描述",
		  							"field_3":"USER_ID",
		  							"field_3_placeholder":"类型 S、I、D、USER_ID、DATETIME,UUID",
		  							"field_4":"",
		  							"field_4_placeholder":"",
		  							"field_5":"",
		  							"field_5_placeholder":"默认值",
		  							},
		  							{"field_1":"updatetime",
		  							"field_1_placeholder":"字段",
		  							"field_2":"是否删除",
		  							"field_2_placeholder":"描述",
		  							"field_3":"DATETIME",
		  							"field_3_placeholder":"类型 S、I、D、USER_ID、DATETIME,UUID",
		  							"field_4":"",
		  							"field_4_placeholder":"",
		  							"field_5":"",
		  							"field_5_placeholder":"默认值",
		  							}
		  						]
		  				},
		  				
		  				]
	  		},
	  		
	  			{
	  			name:"platform_login",
	  			fields:[
	  					{
	  					showName:"",
	  					name:"service_type",
	  					must_send:false,
	  					must_save:true,
	  					type:"hidden",
	  					placeholder:"",
	  					value:"service_platform_login"
	  					},
		  				{
		  					showName:"",
		  					name:"type",
		  					must_send:false,
		  					must_save:true,
		  					type:"hidden",
		  					placeholder:"",
		  					value:"platform_login"
		  				},
		  				{
		  					showName:"service",
		  					name:"service",
		  					must_send:true,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"服务访问名称",
		  				},
		  				{
		  					showName:"备注",
		  					name:"backup",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"",
		  				},
		  				{
		  					showName:"是否需要登陆，login_require",
		  					name:"login_require",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"是否需要登陆",
		  					value:"false"
		  				},
		  				{
		  					showName:"是否记住登陆，remember_me",
		  					name:"remember_me",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"是否记住登陆",
		  					value:"false"
		  				},
		  				{
		  					showName:'登陆字段',
		  					name:"fields",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"登陆字段",
		  					value:[

		  							{
		  								"field_1":"username",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"用户名",
			  							"field_2_placeholder":"描述",
			  							"field_3":"S,must",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列校验规则。如S，must。表示类型为字符串。必须传",
			  							"field_4":"",
			  							"field_4_placeholder":"是否伪删除,必须为JSON",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							},
		  							{
		  								"field_1":"password",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"密码",
			  							"field_2_placeholder":"描述",
			  							"field_3":"S,must",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列校验规则。如S，must。表示类型为字符串。必须传",
			  							"field_4":'',
			  							"field_4_placeholder":"是否伪删除,必须为JSON",
			  							'field_5':'',
			  							"field_5_placeholder":"默认值"
		  							},
		  							{
		  								"field_1":"alwaysLogin",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"是否强制登陆",
			  							"field_2_placeholder":"描述",
			  							"field_3":"S",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列校验规则。如S，must。表示类型为字符串。必须传",
			  							"field_4":'',
			  							"field_4_placeholder":"是否伪删除,必须为JSON",
			  							'field_5':'false',
			  							"field_5_placeholder":"默认值"
		  							},


		  							
		  							]
		  				}
		  				]
	  		}

	  		,
	  		
	  			{
	  			name:"version_iteration",
	  			fields:[
	  					{
	  					showName:"",
	  					name:"service_type",
	  					must_send:false,
	  					must_save:true,
	  					type:"hidden",
	  					placeholder:"",
	  					value:"service_version_iteration"
	  					},
		  				{
		  					showName:"",
		  					name:"type",
		  					must_send:false,
		  					must_save:true,
		  					type:"hidden",
		  					placeholder:"",
		  					value:"version_iteration"
		  				},
		  				{
		  					showName:"service",
		  					name:"service",
		  					must_send:true,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"服务访问名称",
		  				},
		  				{
		  					showName:"备注",
		  					name:"backup",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"",
		  				},
		  				{
		  					showName:"是否需要登陆，login_require",
		  					name:"login_require",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"是否需要登陆",
		  					value:"true"
		  				},
		  			
		  				{
		  					showName:'修改数据字段',
		  					name:"fields",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"登陆字段",
		  					value:[

		  							{
		  								"field_1":"name",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"名称",
			  							"field_2_placeholder":"描述",
			  							"field_3":"S,must",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列校验规则。如S，must。表示类型为字符串。必须传",
			  							"field_4":"",
			  							"field_4_placeholder":"是否伪删除,必须为JSON",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							},
		  							{
		  								"field_1":"url",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"访问地址",
			  							"field_2_placeholder":"描述",
			  							"field_3":"S,must",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列校验规则。如S，must。表示类型为字符串。必须传",
			  							"field_4":'',
			  							"field_4_placeholder":"是否伪删除,必须为JSON",
			  							'field_5':'',
			  							"field_5_placeholder":"默认值"
		  							},
		  							


		  							
		  							]
		  				},

		  				{
		  					showName:"条件筛选字段",
		  					name:"filters",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"条件筛选字段",
		  					value:[
		  							
		  							{"field_1":"id",
		  							"field_1_placeholder":"字段",
		  							"field_2":"id",
		  							"field_2_placeholder":"描述",
		  							"field_3":"S",
		  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列校验规则。如S，must。表示类型为字符串。必须传",
		  							"field_4":"",
		  							"field_4_placeholder":"",
		  							"field_5":'',
		  							"field_5_placeholder":"默认值",
		  							}
		  						]
		  				}
		  				]
	  		}

	  		,
	  		
	  			{
	  			name:"database_table",
	  			fields:[
	  					{
	  					showName:"",
	  					name:"service_type",
	  					must_send:false,
	  					must_save:true,
	  					type:"hidden",
	  					placeholder:"",
	  					value:"service_database_table"
	  					},
		  				{
		  					showName:"",
		  					name:"type",
		  					must_send:false,
		  					must_save:true,
		  					type:"hidden",
		  					placeholder:"",
		  					value:"database_table"
		  				},
		  				{
		  					showName:"service",
		  					name:"service",
		  					must_send:true,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"服务访问名称",
		  				},
		  				{
		  					showName:"备注",
		  					name:"backup",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"",
		  				},
		  				{
		  					showName:"是否需要登陆，login_require",
		  					name:"login_require",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"是否需要登陆",
		  					value:"true"
		  				},

		  				{
		  					showName:"table_name ，表名",
		  					name:"table_name",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"数据库表",
		  					value:""
		  				},
		  			
		  				{
		  					showName:'字段名称',
		  					name:"fields",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"",
		  					value:[
		  							{
		  								"field_1":"id",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"id",
			  							"field_2_placeholder":"描述",
			  							"field_3":"varchar,255",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列长度",
			  							"field_4":"primary_key",
			  							"field_4_placeholder":"",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							},

		  							{
		  								"field_1":"name",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"名称",
			  							"field_2_placeholder":"描述",
			  							"field_3":"varchar,255",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列长度",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							},
		  							{
		  								"field_1":"create_time",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"创建时间",
			  							"field_2_placeholder":"描述",
			  							"field_3":"varchar,255",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列长度",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							},
		  							
		  							{
		  								"field_1":"create_by",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"创建人",
			  							"field_2_placeholder":"描述",
			  							"field_3":"varchar,255",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列长度",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							},
		  							{
		  								"field_1":"update_time",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"创建时间",
			  							"field_2_placeholder":"描述",
			  							"field_3":"varchar,255",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列长度",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							},
		  							
		  							{
		  								"field_1":"update_by",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"修改人",
			  							"field_2_placeholder":"描述",
			  							"field_3":"varchar,255",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列长度",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							},

		  							{
		  								"field_1":"delete_flag",
			  							"field_1_placeholder":"字段名称",
			  							"field_2":"是否删除",
			  							"field_2_placeholder":"描述",
			  							"field_3":"varchar,255",
			  							"field_3_placeholder":"以逗号分割 ，第一列类型，第二列长度",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							}

		  							
		  							]
		  				},
		  				{
		  					showName:"engine ，引擎",
		  					name:"engine",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"innodb，myisam",
		  					value:"innodb"
		  				},
		  				{
		  					showName:"init_data_service ，初始化数据",
		  					name:"init_data_service",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"初始化数据",
		  					value:""
		  				},
		  			
		  				]
	  		}
	  		,{
	  			name:"file_upload_save",
	  			fields:[
	  					{
	  					showName:"",
	  					name:"service_type",
	  					must_send:false,
	  					must_save:true,
	  					type:"hidden",
	  					placeholder:"",
	  					value:"service_file_upload_save"
	  					},
		  				{
		  					showName:"",
		  					name:"type",
		  					must_send:false,
		  					must_save:true,
		  					type:"hidden",
		  					placeholder:"",
		  					value:"file_upload_save"
		  				},
		  				{
		  					showName:"service",
		  					name:"service",
		  					must_send:true,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"服务访问名称",
		  				},
		  				{
		  					showName:"备注",
		  					name:"backup",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"",
		  				},
		  				{
		  					showName:"是否需要登陆，login_require",
		  					name:"login_require",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"是否需要登陆",
		  					value:"true"
		  				},

		  				{
		  					showName:"accept ，文件格式",
		  					name:"accept",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"以逗号分割，例如.jpg,.png,.gif,.wlkx",
		  					value:""
		  				},
		  				{
		  					showName:"max_size ，文件大小（M）",
		  					name:"max_size",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"文件大小，例如500",
		  					value:""
		  				},
		  			
		  				
		  				{
		  					showName:"process_data_service ,处理数据服务",
		  					name:"process_data_service",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"处理数据服务",
		  					value:""
		  				},

		  				{
		  					showName:'保存根目录',
		  					name:"root",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"",
		  					value:"C:/file/files/"
		  				},

		  				{
		  					showName:'保存目录规则',
		  					name:"path",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"",
		  					value:[
		  						
		  							{
		  								"field_1":"day",
			  							"field_1_placeholder":"日期",
			  							"field_2":"",
			  							"field_2_placeholder":"",
			  							"field_3":"day",
			  							"field_3_placeholder":"规则列 day 获取日期，当前count累加 除以1000后的值,user_id_4",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							},
		  							{
		  								"field_1":"count",
			  							"field_1_placeholder":"计数",
			  							"field_2":"",
			  							"field_2_placeholder":"",
			  							"field_3":"count",
			  							"field_3_placeholder":"规则列 day 获取日期，当前count累加 除以1000后的值",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"1000",
			  							"field_5_placeholder":"默认值"
		  							},

		  							{
		  								"field_1":"user_id_4",
			  							"field_1_placeholder":"日期",
			  							"field_2":"",
			  							"field_2_placeholder":"",
			  							"field_3":"user_id_4",
			  							"field_3_placeholder":"规则列 day 获取日期，当前count累加 除以1000后的值,user_id_4 用户ID的前4位",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							},
		  					]
		  				},

		  				{
		  					showName:'访问目录前缀，nginx 配置到C:/file',
		  					name:"domain_path",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"",
		  					value:"/files/"
		  				},
		  			

		  				{
		  					showName:'生成数据列',
		  					name:"fields",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"",
		  					value:[
		  							{
		  								"field_1":"code",
			  							"field_1_placeholder":"字段",
			  							"field_2":"",
			  							"field_2_placeholder":"",
			  							"field_3":"",
			  							"field_3_placeholder":"",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							},
		  						
		  							{
		  								"field_1":"file_name",
			  							"field_1_placeholder":"字段",
			  							"field_2":"",
			  							"field_2_placeholder":"",
			  							"field_3":"",
			  							"field_3_placeholder":"",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							},
		  							{
		  								"field_1":"file_index",
			  							"field_1_placeholder":"日期",
			  							"field_2":"",
			  							"field_2_placeholder":"",
			  							"field_3":"",
			  							"field_3_placeholder":"",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							},

		  							{
		  								"field_1":"file_source_path",
			  							"field_1_placeholder":"字段",
			  							"field_2":"",
			  							"field_2_placeholder":"",
			  							"field_3":"",
			  							"field_3_placeholder":"",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							},

		  							{
		  								"field_1":"file_domain_path",
			  							"field_1_placeholder":"字段",
			  							"field_2":"",
			  							"field_2_placeholder":"",
			  							"field_3":"",
			  							"field_3_placeholder":"",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"",
			  							"field_5_placeholder":"默认值"
		  							}
		  					]
		  				}
		  				]
	  		}

	  		,{
	  			name:"database_connection_config",
	  			fields:[
	  					{
	  					showName:"",
	  					name:"service_type",
	  					must_send:false,
	  					must_save:true,
	  					type:"hidden",
	  					placeholder:"",
	  					value:"service_database_connection_config"
	  					},
		  				{
		  					showName:"",
		  					name:"type",
		  					must_send:false,
		  					must_save:true,
		  					type:"hidden",
		  					placeholder:"",
		  					value:"database_connection_config"
		  				},
		  				{
		  					showName:"service",
		  					name:"service",
		  					must_send:true,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"服务访问名称",
		  				},
		  				{
		  					showName:"备注",
		  					name:"backup",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"",
		  				},
		  				{
		  					showName:"是否需要登陆，login_require",
		  					name:"login_require",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"是否需要登陆",
		  					value:"true"
		  				},

		  				{
		  					showName:"database_type ,数据库类型",
		  					name:"database_type",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"mysql,oracle,sqlserver",
		  					value:"mysql"
		  				},
		  				{
		  					showName:"class_name，驱动",
		  					name:"class_name",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"驱动",
		  					value:"com.mysql.jdbc.Driver"
		  				},
		  				{
		  					showName:"host,数据库ip",
		  					name:"host",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"数据库ip",
		  					value:""
		  				},
		  			
		  				
		  				{
		  					showName:"username ,用户名",
		  					name:"username",
		  					must_send:false,
		  					must_save:true,
		  					type:"input",
		  					placeholder:"用户名",
		  					value:""
		  				},

		  				{
		  					showName:'password,密码',
		  					name:"password",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"密码",
		  					value:""
		  				},
		  				{
		  					showName:'database,数据库',
		  					name:"database",
		  					must_send:false,
		  					must_save:false,
		  					type:"input",
		  					placeholder:"数据库",
		  					value:""
		  				},

		  				{
                                showName:'fields',
                                name:"fields",
                                must_send:false,
                                must_save:false,
                                type:"array",
                                placeholder:"",
                                value:[
                                    {
                                        "field_1":"connection_update",
                                        "field_1_placeholder":"是否更改连接",
                                        "field_2":"是否更改连接",
                                        "field_2_placeholder":"",
                                        "field_3":"S",
                                        "field_3_placeholder":"",
                                        "field_4":"",
                                        "field_4_placeholder":"",
                                        "field_5":"false",
                                        "field_5_placeholder":"默认值"
                                    },
                                     {
                                        "field_1":"table_update",
                                        "field_1_placeholder":"是否更新表结构",
                                        "field_2":"是否更新表结构",
                                        "field_2_placeholder":"",
                                        "field_3":"S",
                                        "field_3_placeholder":"",
                                        "field_4":"",
                                        "field_4_placeholder":"",
                                        "field_5":"false",
                                        "field_5_placeholder":"默认值"
                                    }
                                ]
                        },

		  				{
		  					showName:'property',
		  					name:"property",
		  					must_send:false,
		  					must_save:false,
		  					type:"array",
		  					placeholder:"",
		  					value:[
		  						
		  							{
		  								"field_1":"initialSize",
			  							"field_1_placeholder":"连接池数",
			  							"field_2":"连接数",
			  							"field_2_placeholder":"",
			  							"field_3":"I",
			  							"field_3_placeholder":"",
			  							"field_4":"",
			  							"field_4_placeholder":"",
			  							"field_5":"1",
			  							"field_5_placeholder":"默认值"
		  							}
		  					]
		  				}


		  				]
	  		}


	  	]	
	}
}


window.$config = config