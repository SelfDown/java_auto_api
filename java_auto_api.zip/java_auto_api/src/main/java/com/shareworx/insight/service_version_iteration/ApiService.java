package com.shareworx.insight.service_version_iteration;

public interface ApiService {
}
