package com.shareworx.insight.utils;


import java.util.List;

public class StringJoinUtils {
    public static String join( Object[] o , String flag ){
        StringBuffer str_buff = new StringBuffer();

        for(int i=0 , len=o.length ; i<len ; i++){
            str_buff.append( String.valueOf( o[i] ) );
            if(i<len-1)str_buff.append( flag );
        }

        return str_buff.toString();
    }

    public static String join(List o , String flag ){
        StringBuffer str_buff = new StringBuffer();

        for(int i=0 , len=o.size() ; i<len ; i++){
            str_buff.append( String.valueOf( o.get(i) ) );
            if(i<len-1)str_buff.append( flag );
        }

        return str_buff.toString();
    }

}
