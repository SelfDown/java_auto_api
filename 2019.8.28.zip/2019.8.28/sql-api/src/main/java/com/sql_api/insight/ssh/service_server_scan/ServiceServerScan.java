package com.sql_api.insight.ssh.service_server_scan;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sql_api.insight.model.ApiModel;
import com.sql_api.insight.service.ResultBaseService;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.*;


@Service(ServiceServerScan.ID)
public class ServiceServerScan extends ResultBaseService implements ApiService {
    public static final String ID ="service_server_scan";
    @Override
    public Map<String, Object> result(Map<String, Object> actual) {
        Map<String,Object> test = new HashMap<>();
        String service = (String) actual.get("service");
        ApiModel apiModel = getApiModel(service);
        String template_final = apiModel.getTemplate();
        JSONObject final_template = JSON.parseObject(template_final);
        Map<String, Object> map = checkFields((Map<String, Object>) actual.get("fields"), final_template.getJSONArray("fields"),final_template);
        if(actual.get("fields")==null){
            actual.put("fields",new HashMap<>());
        }
        //检查状态是否成功
        String msg = null;
        if(!(boolean)map.get("success")){
            return map;
        }
        HashMap<String,Object> fields = (HashMap<String, Object>) actual.get("fields");
        Map<String,Object> result= new HashMap<>();
        Map<String, Object> connect = connect(fields.get("ip_matcher") + "", Integer.parseInt(fields.get("port") + ""),300);
        List<Map<String,Object>> data = new ArrayList<>();
        data.add(connect);
        result.put("data",data);
        result.put("success",true);
        result.put("msg","操作成功");
        return result;
    }


    @Override
    public Map<String, Object> connect(String ip, int port,int timeout) {
        long startTime = System.currentTimeMillis();    //获取开始时间的时间戳
        Boolean connect = false;
        Socket socket = new Socket();
        String msg = null;
        try {
            socket.connect(new InetSocketAddress(ip, port),timeout);
            connect = true;
            msg = "连接成功";
        } catch (IOException e) {
            msg = e.getMessage();
            e.printStackTrace();
            connect = false;
        } finally {
            try {
                socket.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        long endTime = System.currentTimeMillis();
        Map<String,Object> map = new HashMap<>();
        map.put("ip",ip);
        map.put("port",port);
        map.put("connect",connect);
        map.put("spend",(endTime - startTime) + "ms");
        map.put("msg",msg);
        return map;
    }
}
