package com.sql_api.insight.service_version_iteration;

public interface ApiService {
}
