package com.sql_api.insight.service_database_connection_config;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.sql_api.insight.data_source.DruidConfiguration;
import com.sql_api.insight.model.ApiModel;
import com.sql_api.insight.service.ResultBaseService;

import com.sql_api.insight.utils.SpringUtils;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@Service(ServiceDatabaseConnectionConfig.ID)
public class ServiceDatabaseConnectionConfig extends ResultBaseService implements ApiService {
    public static final String ID = "service_database_connection_config";
    @Override
    public Map<String, Object> result(Map<String, Object> actual) {
        String service = (String) actual.get("service");
        ApiModel apiModel = getApiModel(service);
        if(apiModel == null){
            return getResult(false,"数据库配置不存在");
        }
        String template_final = apiModel.getTemplate();
        JSONObject final_template = JSON.parseObject(template_final);
        changeField(actual,final_template);
        changeProperty(final_template);
        changeUrl(final_template);
        updateConnection((Map<String, Object>) actual.get("fields"),final_template);





        Map<String,Object> map= new HashMap<>();
        map.put("data",final_template);
        map.put("success",true);
        map.put("msg","查询成功");
       // DatabaseConnectionConfigUtils.ConfigOne(map);
        return map;
    }

    // 获得连接对象
    private  synchronized void testConn(JSONObject template ){

            try {
                String driver = template.getString("ClassName");
                String url = template.getString("url");
                String username = template.getString("username");
                String password = template.getString("password");
                Class.forName(driver);
                Connection connection = DriverManager.getConnection(url, username, password);
                connection.close();
                template.put("msg","连接成功");
                template.put("success",true);
            } catch (Exception e) {
                e.printStackTrace();
                template.put("msg",e.toString());
                template.put("success",false);
            }


    }

    private void changeUrl(JSONObject final_template){
        String database_type = final_template.getString("database_type").toLowerCase();
        if("mysql".equals(database_type)){
            String url = "jdbc:mysql://"+final_template.getString("host")+":3306/"+final_template.getString("database")+"?useUnicode=true&characterEncoding=UTF8";
            final_template.put("url",url);
        }else if("oracle".equals(database_type)){
            String url ="jdbc:oracle:thin:@"+final_template.getString("host")+":1521:"+final_template.getString("database");
            final_template.put("url",url);
        }
    }

    private void changeField(Map<String, Object> actual,JSONObject final_template){
        JSONArray fields = final_template.getJSONArray("fields");
        Map<String,Object> field_map = new HashMap<>();
        for(int i =0;i<fields.size();i++){
            JSONObject fieldsJSONObject = fields.getJSONObject(i);
            String field_1 = fieldsJSONObject.getString("field_1");

            if(actual.containsKey(field_1)){
                String value = (String) actual.get(field_1);
                if("true".equals(value)){
                    value = "true";
                }else{
                    value = "false";
                }
                field_map.put(field_1,value);
            }else{
                field_map.put(field_1,fieldsJSONObject.getString("field_5"));
            }
        }

        final_template.put("fields",field_map);
    }

    private void changeProperty(JSONObject final_template){
        JSONArray property = final_template.getJSONArray("property");
        Map<String,Object> propertyMap = new HashMap<>();
        for(int i =0;i<property.size();i++){
            JSONObject jsonObject = property.getJSONObject(i);
            propertyMap.put(jsonObject.getString("field_1"),jsonObject.getString("field_5"));
        }
        final_template.put("property",propertyMap);

    }



    private  void updateConnection(Map<String, Object> actual,JSONObject final_template){

        Map<String,Object> fields = (Map<String, Object>) final_template.get("fields");
        String connection_update = (String) fields.get("connection_update");
        if(actual == null){
            actual = new HashMap<>();
        }
        if(!actual.containsKey("connection_update")){
            actual.put("connection_update",connection_update);
        }
        //如果更新数据库连接
        if("true".equals(actual.get("connection_update"))){
            testConn(final_template);
            Boolean success = final_template.getBoolean("success");
            if(!success){
                return ;
            }
            DruidConfiguration druidConfiguration = SpringUtils.getBean(DruidConfiguration.ID);
            DataSource dataSource = druidConfiguration.getDataSource(final_template);
            try {
                boolean closed = dataSource.getConnection().isClosed();
                if(closed){
                    dataSource.getConnection().close();
                    final_template.put("msg","连接失败");
                    return;
                }
            } catch (Exception e) {
                final_template.put("msg","连接失败");
                e.printStackTrace();
                return ;
            }
            String service = final_template.getString("service");
            //service 名称必须和数据连接名称相同
            JdbcTemplate jdbcTemplate = SpringUtils.getBean(service);
            if(jdbcTemplate !=null){
                try {
                    jdbcTemplate.getDataSource().getConnection().close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                jdbcTemplate.setDataSource(dataSource);
                final_template.put("msg","连接成功");
            }
        }
    }
}
