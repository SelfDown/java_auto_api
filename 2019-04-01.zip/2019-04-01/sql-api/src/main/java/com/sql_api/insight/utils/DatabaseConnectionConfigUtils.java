package com.sql_api.insight.utils;

import com.alibaba.fastjson.JSONObject;
import com.sql_api.insight.service.Result;
import com.sql_api.insight.service_database_connection_config.ServiceDatabaseConnectionConfig;

import java.util.HashMap;
import java.util.Map;

public class DatabaseConnectionConfigUtils {


    public static Map<String,Object> result(String service,Map<String,Object> fields){
        Result result_service = SpringUtils.getBean(ServiceDatabaseConnectionConfig.ID);
        Map<String,Object> service_data = new HashMap<>();
        service_data.put("service",service);
        service_data.put("fields",fields);
        return result_service.result(service_data);
    }
    public static JSONObject ConfigOne(Map<String,Object> result){
        return (JSONObject) result.get("data");

    }
}
